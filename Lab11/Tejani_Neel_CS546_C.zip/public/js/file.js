(function ($) {
    function bindShow(showName) {
        $("#showList").append(
            `<li><a id=${showName.id} href=${showName._links.self.href}>${showName.name}</a></li>`
        );
        $(`#${showName.id}`).on("click", linkClicked);
    }
    function linkClicked(event) {
        // to prevent the load page
        event.preventDefault();
        $("#showList").hide();
        $("#show").empty();
        $("#homeLink").show();
        $.ajax({
            type: "GET",
            url: this.href,
        }).then(function (response) {
            const show = $(response)[0];

            let name;
            if (show.name != null) {
                name = show.name;
            } else {
                name = "N/A";
            }
            let image;
            if (show.image == null || show.image.medium == null) {
                image = "public/no_image.jpeg";
            } else {
                image = show.image.medium;
            }
            let language;
            if (show.language != null) {
                language = show.language;
            } else {
                language = "N/A";
            }
            let rating;
            if (show.rating == null || show.rating.average == null) {
                rating = "N/A";
            } else {
                rating = show.rating.average;
            }
            let network;
            if (show.network == null || show.network.name == null) {
                network = "N/A";
            } else {
                network = show.network.name;
            }
            let summary, liTag;
            if (show.summary == null) {
                summary = "N/A";
            } else {
                summary = show.summary;
            }

            $("#show").append(`<h1>${name}</h1>`);
            $("#show").append(`<img src=${image}></img>`);
            $("#show").append(`<dl>Language<dd>${language}</dd></dl>`);

            if (show.genres == null) {
                liTag = "<li>N/A</li>";
            } else {
                liTag = "";
                for (let i = 0; i < show.genres.length; i++) {
                    liTag += `<li>${show.genres[i]}</li>`;
                }
            }
            $("#show").append(`<dl>Genres<dd><ul>${liTag}</ul></dd></dl>`);
            $("#show").append(`<dl>Average Rating<dd>${rating}</dd></dl>`);
            $("#show").append(`<dl>Network<dd>${network}</dd></dl>`);
            $("#show").append(`<dl>Summary<dd>${summary}</dd></dl>`);

            $("#show").show();
        });
    }

    $.ajax({
        type: "GET",
        url: "http://api.tvmaze.com/shows",
    }).then(function (response) {
        $("#showList").show();
        $("#show").hide();
        var shows = $(response);
        for (let i = 0; i < shows.length; i++) {
            bindShow(shows[i]);
        }
    });

    $("#searchForm").submit(function (event) {
        event.preventDefault();
        let search = $("#search_term").val().trim();
        if (search.length == 0) {
            alert("Enter Show Name");
            return;
        }

        $("#showList").empty();
        $.ajax({
            type: "GET",
            url: `http://api.tvmaze.com//search/shows?q=${search}`,
        }).then(function (response) {
            $("#showList").show();
            $("#show").hide();
            $("#homeLink").show();
            var shows = $(response);
            for (let i = 0; i < shows.length; i++) {
                bindShow(shows[i].show);
            }
        });
    });
})(window.jQuery);
